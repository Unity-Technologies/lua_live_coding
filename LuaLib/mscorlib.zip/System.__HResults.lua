---@class System.__HResults : System.Object
local m = {}

System.__HResults = m
return m
