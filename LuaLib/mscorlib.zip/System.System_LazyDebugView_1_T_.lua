---@class System.System_LazyDebugView_1_T_ : System.Object
---@field public IsValueCreated boolean
---@field public Value any
---@field public Mode System.Threading.LazyThreadSafetyMode
---@field public IsValueFaulted boolean
local m = {}

System.System_LazyDebugView_1_T_ = m
return m
