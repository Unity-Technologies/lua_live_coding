---@class System.RuntimeMethodHandleInternal : System.ValueType
local m = {}

System.RuntimeMethodHandleInternal = m
return m
