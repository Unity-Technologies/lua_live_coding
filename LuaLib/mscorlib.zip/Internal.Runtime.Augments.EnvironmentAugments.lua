---@class Internal.Runtime.Augments.EnvironmentAugments : System.Object
---@field public StackTrace string @static
local m = {}

Internal.Runtime.Augments.EnvironmentAugments = m
return m
