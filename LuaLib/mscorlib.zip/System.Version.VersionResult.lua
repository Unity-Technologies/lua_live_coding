---@class System.Version.VersionResult : System.ValueType
local m = {}

System.Version.VersionResult = m
return m
