---@class System.RuntimeType.MemberListType : System.Enum
---@field public All System.RuntimeType.MemberListType @static
---@field public CaseSensitive System.RuntimeType.MemberListType @static
---@field public CaseInsensitive System.RuntimeType.MemberListType @static
---@field public HandleToInfo System.RuntimeType.MemberListType @static
---@field public value__ number
local m = {}

System.RuntimeType.MemberListType = m
return m
