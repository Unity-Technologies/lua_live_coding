---@class System.EntryPointNotFoundException : System.TypeLoadException
local m = {}

System.EntryPointNotFoundException = m
return m
