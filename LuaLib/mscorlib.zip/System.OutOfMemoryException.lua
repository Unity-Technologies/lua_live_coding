---@class System.OutOfMemoryException : System.SystemException
local m = {}

System.OutOfMemoryException = m
return m
