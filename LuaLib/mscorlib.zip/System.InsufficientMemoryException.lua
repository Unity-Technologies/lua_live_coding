---@class System.InsufficientMemoryException : System.OutOfMemoryException
local m = {}

System.InsufficientMemoryException = m
return m
