---@class System.Version.ParseFailureKind : System.Enum
---@field public ArgumentNullException System.Version.ParseFailureKind @static
---@field public ArgumentException System.Version.ParseFailureKind @static
---@field public ArgumentOutOfRangeException System.Version.ParseFailureKind @static
---@field public FormatException System.Version.ParseFailureKind @static
---@field public value__ number
local m = {}

System.Version.ParseFailureKind = m
return m
