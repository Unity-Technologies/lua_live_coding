---@class System.GC.StartNoGCRegionStatus : System.Enum
---@field public Succeeded System.GC.StartNoGCRegionStatus @static
---@field public NotEnoughMemory System.GC.StartNoGCRegionStatus @static
---@field public AmountTooLarge System.GC.StartNoGCRegionStatus @static
---@field public AlreadyInProgress System.GC.StartNoGCRegionStatus @static
---@field public value__ number
local m = {}

System.GC.StartNoGCRegionStatus = m
return m
