---@class System.CompatibilitySwitches : System.Object
---@field public IsAppEarlierThanSilverlight4 boolean @static
---@field public IsAppEarlierThanWindowsPhone8 boolean @static
local m = {}

System.CompatibilitySwitches = m
return m
