---@class System.EventArgs : System.Object
---@field public Empty System.EventArgs @static
local m = {}

System.EventArgs = m
return m
