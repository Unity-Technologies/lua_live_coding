---@class System.MemoryDebugView_1_T_ : System.Object
---@field public Items any[]
local m = {}

System.MemoryDebugView_1_T_ = m
return m
