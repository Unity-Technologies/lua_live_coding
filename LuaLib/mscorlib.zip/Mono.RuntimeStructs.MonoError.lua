---@class Mono.RuntimeStructs.MonoError : System.ValueType
local m = {}

Mono.RuntimeStructs.MonoError = m
return m
