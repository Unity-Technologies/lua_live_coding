---@class System.SpanHelpers.Reg64 : System.ValueType
local m = {}

System.SpanHelpers.Reg64 = m
return m
