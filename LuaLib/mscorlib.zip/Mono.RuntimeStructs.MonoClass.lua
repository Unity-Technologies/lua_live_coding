---@class Mono.RuntimeStructs.MonoClass : System.ValueType
local m = {}

Mono.RuntimeStructs.MonoClass = m
return m
