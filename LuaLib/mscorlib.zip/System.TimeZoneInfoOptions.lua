---@class System.TimeZoneInfoOptions : System.Enum
---@field public None System.TimeZoneInfoOptions @static
---@field public NoThrowOnInvalidTime System.TimeZoneInfoOptions @static
---@field public value__ number
local m = {}

System.TimeZoneInfoOptions = m
return m
