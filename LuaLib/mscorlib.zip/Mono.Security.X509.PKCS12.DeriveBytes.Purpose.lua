---@class Mono.Security.X509.PKCS12.DeriveBytes.Purpose : System.Enum
---@field public Key Mono.Security.X509.PKCS12.DeriveBytes.Purpose @static
---@field public IV Mono.Security.X509.PKCS12.DeriveBytes.Purpose @static
---@field public MAC Mono.Security.X509.PKCS12.DeriveBytes.Purpose @static
---@field public value__ number
local m = {}

Mono.Security.X509.PKCS12.DeriveBytes.Purpose = m
return m
