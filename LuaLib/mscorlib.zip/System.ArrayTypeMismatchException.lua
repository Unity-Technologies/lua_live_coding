---@class System.ArrayTypeMismatchException : System.SystemException
local m = {}

System.ArrayTypeMismatchException = m
return m
