---@class System.ParamsArray : System.ValueType
---@field public Length number
---@field public Item any
local m = {}

System.ParamsArray = m
return m
