---@class System.__DTString : System.ValueType
local m = {}

System.__DTString = m
return m
