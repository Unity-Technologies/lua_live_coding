---@class System.ResId : System.Object
local m = {}

System.ResId = m
return m
