---@class System.Pinnable_1_T_ : System.Object
---@field public Data any
local m = {}

System.Pinnable_1_T_ = m
return m
