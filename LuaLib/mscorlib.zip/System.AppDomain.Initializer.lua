---@class System.AppDomain.Initializer : System.Object
local m = {}

function m:Initialize() end

System.AppDomain.Initializer = m
return m
