---@class System.Guid.ParseFailureKind : System.Enum
---@field public None System.Guid.ParseFailureKind @static
---@field public ArgumentNull System.Guid.ParseFailureKind @static
---@field public Format System.Guid.ParseFailureKind @static
---@field public FormatWithParameter System.Guid.ParseFailureKind @static
---@field public NativeException System.Guid.ParseFailureKind @static
---@field public FormatWithInnerException System.Guid.ParseFailureKind @static
---@field public value__ number
local m = {}

System.Guid.ParseFailureKind = m
return m
