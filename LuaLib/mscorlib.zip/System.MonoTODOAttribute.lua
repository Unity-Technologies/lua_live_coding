---@class System.MonoTODOAttribute : System.Attribute
---@field public Comment string
local m = {}

System.MonoTODOAttribute = m
return m
