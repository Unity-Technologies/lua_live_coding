---@class System.ThreadStaticAttribute : System.Attribute
local m = {}

System.ThreadStaticAttribute = m
return m
