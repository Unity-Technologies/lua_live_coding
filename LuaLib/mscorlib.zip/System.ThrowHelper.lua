---@class System.ThrowHelper : System.Object
local m = {}

System.ThrowHelper = m
return m
