---@class Mono.Security.Authenticode.AuthenticodeBase : System.Object
---@field public spcIndirectDataContext string @static
local m = {}

Mono.Security.Authenticode.AuthenticodeBase = m
return m
