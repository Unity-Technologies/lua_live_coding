---@class UnityEngine.Skybox : UnityEngine.Behaviour
---@field public material UnityEngine.Material
local m = {}

UnityEngine.Skybox = m
return m
