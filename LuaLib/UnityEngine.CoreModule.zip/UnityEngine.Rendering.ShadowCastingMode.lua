---@class UnityEngine.Rendering.ShadowCastingMode : System.Enum
---@field public Off UnityEngine.Rendering.ShadowCastingMode @static
---@field public On UnityEngine.Rendering.ShadowCastingMode @static
---@field public TwoSided UnityEngine.Rendering.ShadowCastingMode @static
---@field public ShadowsOnly UnityEngine.Rendering.ShadowCastingMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ShadowCastingMode = m
return m
