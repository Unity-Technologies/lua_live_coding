---@class UnityEngine.BlendWeights : System.Enum
---@field public OneBone UnityEngine.BlendWeights @static
---@field public TwoBones UnityEngine.BlendWeights @static
---@field public FourBones UnityEngine.BlendWeights @static
---@field public value__ number
local m = {}

UnityEngine.BlendWeights = m
return m
