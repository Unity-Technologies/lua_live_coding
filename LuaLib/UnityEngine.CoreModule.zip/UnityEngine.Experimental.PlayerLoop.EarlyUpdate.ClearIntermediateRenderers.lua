---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ClearIntermediateRenderers : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ClearIntermediateRenderers = m
return m
