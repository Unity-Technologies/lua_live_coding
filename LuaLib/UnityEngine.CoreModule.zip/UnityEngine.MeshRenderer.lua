---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
---@field public additionalVertexStreams UnityEngine.Mesh
---@field public subMeshStartIndex number
local m = {}

UnityEngine.MeshRenderer = m
return m
