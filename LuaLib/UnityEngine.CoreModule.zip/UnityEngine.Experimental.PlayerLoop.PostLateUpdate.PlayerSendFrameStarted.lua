---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFrameStarted : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerSendFrameStarted = m
return m
