---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UnityConnectClientUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UnityConnectClientUpdate = m
return m
