---@class UnityEngine.Rendering.GraphicsTier : System.Enum
---@field public Tier1 UnityEngine.Rendering.GraphicsTier @static
---@field public Tier2 UnityEngine.Rendering.GraphicsTier @static
---@field public Tier3 UnityEngine.Rendering.GraphicsTier @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.GraphicsTier = m
return m
