---@class UnityEngine.FogMode : System.Enum
---@field public Linear UnityEngine.FogMode @static
---@field public Exponential UnityEngine.FogMode @static
---@field public ExponentialSquared UnityEngine.FogMode @static
---@field public value__ number
local m = {}

UnityEngine.FogMode = m
return m
