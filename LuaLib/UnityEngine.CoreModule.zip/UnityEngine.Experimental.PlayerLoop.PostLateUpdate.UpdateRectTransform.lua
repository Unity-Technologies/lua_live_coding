---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateRectTransform : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateRectTransform = m
return m
