---@class UnityEngine.jvalue : System.ValueType
---@field public z boolean
---@field public b number
---@field public c number
---@field public s number
---@field public i number
---@field public j number
---@field public f number
---@field public d number
---@field public l System.IntPtr
local m = {}

UnityEngine.jvalue = m
return m
