---@class UnityEngine.Experimental.PlayerLoop.Initialization : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization = m
return m
