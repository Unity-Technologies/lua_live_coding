---@class UnityEngine.ExecuteInEditMode : System.Attribute
local m = {}

UnityEngine.ExecuteInEditMode = m
return m
