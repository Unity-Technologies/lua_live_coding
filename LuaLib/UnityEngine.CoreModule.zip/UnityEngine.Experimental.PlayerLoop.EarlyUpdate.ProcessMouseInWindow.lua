---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProcessMouseInWindow : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ProcessMouseInWindow = m
return m
