---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.CloudWebServicesUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.CloudWebServicesUpdate = m
return m
