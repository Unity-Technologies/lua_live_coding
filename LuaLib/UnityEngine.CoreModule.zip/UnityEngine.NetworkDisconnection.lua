---@class UnityEngine.NetworkDisconnection : System.Enum
---@field public value__ number
local m = {}

UnityEngine.NetworkDisconnection = m
return m
