---@class UnityEngine.Rendering.ReflectionProbeTimeSlicingMode : System.Enum
---@field public AllFacesAtOnce UnityEngine.Rendering.ReflectionProbeTimeSlicingMode @static
---@field public IndividualFaces UnityEngine.Rendering.ReflectionProbeTimeSlicingMode @static
---@field public NoTimeSlicing UnityEngine.Rendering.ReflectionProbeTimeSlicingMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeTimeSlicingMode = m
return m
