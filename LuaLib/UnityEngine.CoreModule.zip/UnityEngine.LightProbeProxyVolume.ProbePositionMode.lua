---@class UnityEngine.LightProbeProxyVolume.ProbePositionMode : System.Enum
---@field public CellCorner UnityEngine.LightProbeProxyVolume.ProbePositionMode @static
---@field public CellCenter UnityEngine.LightProbeProxyVolume.ProbePositionMode @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.ProbePositionMode = m
return m
