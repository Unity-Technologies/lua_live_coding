---@class UnityEngine.ArrayUtils : System.Object
local m = {}

UnityEngine.ArrayUtils = m
return m
