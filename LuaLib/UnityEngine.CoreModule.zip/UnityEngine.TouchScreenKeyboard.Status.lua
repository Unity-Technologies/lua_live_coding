---@class UnityEngine.TouchScreenKeyboard.Status : System.Enum
---@field public Visible UnityEngine.TouchScreenKeyboard.Status @static
---@field public Done UnityEngine.TouchScreenKeyboard.Status @static
---@field public Canceled UnityEngine.TouchScreenKeyboard.Status @static
---@field public LostFocus UnityEngine.TouchScreenKeyboard.Status @static
---@field public value__ number
local m = {}

UnityEngine.TouchScreenKeyboard.Status = m
return m
