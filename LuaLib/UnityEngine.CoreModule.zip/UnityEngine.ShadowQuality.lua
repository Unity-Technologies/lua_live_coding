---@class UnityEngine.ShadowQuality : System.Enum
---@field public Disable UnityEngine.ShadowQuality @static
---@field public HardOnly UnityEngine.ShadowQuality @static
---@field public All UnityEngine.ShadowQuality @static
---@field public value__ number
local m = {}

UnityEngine.ShadowQuality = m
return m
