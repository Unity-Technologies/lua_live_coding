---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerEmitCanvasGeometry : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerEmitCanvasGeometry = m
return m
