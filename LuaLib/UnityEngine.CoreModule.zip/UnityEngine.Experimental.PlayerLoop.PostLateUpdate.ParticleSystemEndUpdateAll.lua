---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ParticleSystemEndUpdateAll : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ParticleSystemEndUpdateAll = m
return m
