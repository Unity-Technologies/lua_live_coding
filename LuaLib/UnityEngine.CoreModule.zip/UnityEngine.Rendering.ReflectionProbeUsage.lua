---@class UnityEngine.Rendering.ReflectionProbeUsage : System.Enum
---@field public Off UnityEngine.Rendering.ReflectionProbeUsage @static
---@field public BlendProbes UnityEngine.Rendering.ReflectionProbeUsage @static
---@field public BlendProbesAndSkybox UnityEngine.Rendering.ReflectionProbeUsage @static
---@field public Simple UnityEngine.Rendering.ReflectionProbeUsage @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeUsage = m
return m
