---@class UnityEngine.WeightedMode : System.Enum
---@field public None UnityEngine.WeightedMode @static
---@field public In UnityEngine.WeightedMode @static
---@field public Out UnityEngine.WeightedMode @static
---@field public Both UnityEngine.WeightedMode @static
---@field public value__ number
local m = {}

UnityEngine.WeightedMode = m
return m
