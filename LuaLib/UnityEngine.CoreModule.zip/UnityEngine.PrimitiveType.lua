---@class UnityEngine.PrimitiveType : System.Enum
---@field public Sphere UnityEngine.PrimitiveType @static
---@field public Capsule UnityEngine.PrimitiveType @static
---@field public Cylinder UnityEngine.PrimitiveType @static
---@field public Cube UnityEngine.PrimitiveType @static
---@field public Plane UnityEngine.PrimitiveType @static
---@field public Quad UnityEngine.PrimitiveType @static
---@field public value__ number
local m = {}

UnityEngine.PrimitiveType = m
return m
