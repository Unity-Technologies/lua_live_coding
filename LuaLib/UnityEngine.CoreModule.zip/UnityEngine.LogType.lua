---@class UnityEngine.LogType : System.Enum
---@field public Error UnityEngine.LogType @static
---@field public Assert UnityEngine.LogType @static
---@field public Warning UnityEngine.LogType @static
---@field public Log UnityEngine.LogType @static
---@field public Exception UnityEngine.LogType @static
---@field public value__ number
local m = {}

UnityEngine.LogType = m
return m
