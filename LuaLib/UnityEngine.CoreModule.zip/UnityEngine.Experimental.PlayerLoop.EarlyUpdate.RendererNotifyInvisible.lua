---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.RendererNotifyInvisible : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.RendererNotifyInvisible = m
return m
