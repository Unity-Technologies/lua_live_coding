---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UNetUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UNetUpdate = m
return m
