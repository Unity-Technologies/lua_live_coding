---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ParticlesLegacyUpdateAllParticleSystems : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.ParticlesLegacyUpdateAllParticleSystems = m
return m
