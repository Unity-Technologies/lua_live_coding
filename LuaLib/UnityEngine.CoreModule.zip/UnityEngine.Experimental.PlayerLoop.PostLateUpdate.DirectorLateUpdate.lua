---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.DirectorLateUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.DirectorLateUpdate = m
return m
