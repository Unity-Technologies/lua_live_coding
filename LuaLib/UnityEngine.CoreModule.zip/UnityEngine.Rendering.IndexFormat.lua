---@class UnityEngine.Rendering.IndexFormat : System.Enum
---@field public UInt16 UnityEngine.Rendering.IndexFormat @static
---@field public UInt32 UnityEngine.Rendering.IndexFormat @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.IndexFormat = m
return m
