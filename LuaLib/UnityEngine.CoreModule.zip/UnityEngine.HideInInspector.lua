---@class UnityEngine.HideInInspector : System.Attribute
local m = {}

UnityEngine.HideInInspector = m
return m
