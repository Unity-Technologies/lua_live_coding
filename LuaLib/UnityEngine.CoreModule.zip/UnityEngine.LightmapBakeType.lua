---@class UnityEngine.LightmapBakeType : System.Enum
---@field public Realtime UnityEngine.LightmapBakeType @static
---@field public Baked UnityEngine.LightmapBakeType @static
---@field public Mixed UnityEngine.LightmapBakeType @static
---@field public value__ number
local m = {}

UnityEngine.LightmapBakeType = m
return m
