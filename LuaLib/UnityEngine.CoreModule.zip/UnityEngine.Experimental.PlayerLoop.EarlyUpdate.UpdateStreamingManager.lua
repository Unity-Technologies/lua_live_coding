---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateStreamingManager : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateStreamingManager = m
return m
