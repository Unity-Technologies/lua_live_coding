---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateCanvasRectTransform : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateCanvasRectTransform = m
return m
