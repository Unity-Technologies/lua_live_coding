---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.UpdateVideo : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.UpdateVideo = m
return m
