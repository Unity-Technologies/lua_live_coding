---@class UnityEngine.UserAuthorization : System.Enum
---@field public WebCam UnityEngine.UserAuthorization @static
---@field public Microphone UnityEngine.UserAuthorization @static
---@field public value__ number
local m = {}

UnityEngine.UserAuthorization = m
return m
