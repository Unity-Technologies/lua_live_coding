---@class UnityEngine.ShadowResolution : System.Enum
---@field public Low UnityEngine.ShadowResolution @static
---@field public Medium UnityEngine.ShadowResolution @static
---@field public High UnityEngine.ShadowResolution @static
---@field public VeryHigh UnityEngine.ShadowResolution @static
---@field public value__ number
local m = {}

UnityEngine.ShadowResolution = m
return m
