---@class UnityEngine.LightType : System.Enum
---@field public Spot UnityEngine.LightType @static
---@field public Directional UnityEngine.LightType @static
---@field public Point UnityEngine.LightType @static
---@field public Area UnityEngine.LightType @static
---@field public value__ number
local m = {}

UnityEngine.LightType = m
return m
