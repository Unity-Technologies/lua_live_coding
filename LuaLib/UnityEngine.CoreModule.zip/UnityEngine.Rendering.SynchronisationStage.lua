---@class UnityEngine.Rendering.SynchronisationStage : System.Enum
---@field public VertexProcessing UnityEngine.Rendering.SynchronisationStage @static
---@field public PixelProcessing UnityEngine.Rendering.SynchronisationStage @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.SynchronisationStage = m
return m
