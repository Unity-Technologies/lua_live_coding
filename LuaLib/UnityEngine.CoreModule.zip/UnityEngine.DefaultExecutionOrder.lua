---@class UnityEngine.DefaultExecutionOrder : System.Attribute
---@field public order number
local m = {}

UnityEngine.DefaultExecutionOrder = m
return m
