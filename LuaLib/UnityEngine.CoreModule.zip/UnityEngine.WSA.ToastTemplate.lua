---@class UnityEngine.WSA.ToastTemplate : System.Enum
---@field public ToastImageAndText01 UnityEngine.WSA.ToastTemplate @static
---@field public ToastImageAndText02 UnityEngine.WSA.ToastTemplate @static
---@field public ToastImageAndText03 UnityEngine.WSA.ToastTemplate @static
---@field public ToastImageAndText04 UnityEngine.WSA.ToastTemplate @static
---@field public ToastText01 UnityEngine.WSA.ToastTemplate @static
---@field public ToastText02 UnityEngine.WSA.ToastTemplate @static
---@field public ToastText03 UnityEngine.WSA.ToastTemplate @static
---@field public ToastText04 UnityEngine.WSA.ToastTemplate @static
---@field public value__ number
local m = {}

UnityEngine.WSA.ToastTemplate = m
return m
