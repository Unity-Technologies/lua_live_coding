---@class UnityEngine.LightRenderMode : System.Enum
---@field public Auto UnityEngine.LightRenderMode @static
---@field public ForcePixel UnityEngine.LightRenderMode @static
---@field public ForceVertex UnityEngine.LightRenderMode @static
---@field public value__ number
local m = {}

UnityEngine.LightRenderMode = m
return m
