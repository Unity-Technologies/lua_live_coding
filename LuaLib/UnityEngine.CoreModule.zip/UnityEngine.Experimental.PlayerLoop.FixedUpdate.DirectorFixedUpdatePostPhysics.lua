---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedUpdatePostPhysics : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedUpdatePostPhysics = m
return m
