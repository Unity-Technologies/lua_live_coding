---@class UnityEngine.LightShadows : System.Enum
---@field public None UnityEngine.LightShadows @static
---@field public Hard UnityEngine.LightShadows @static
---@field public Soft UnityEngine.LightShadows @static
---@field public value__ number
local m = {}

UnityEngine.LightShadows = m
return m
