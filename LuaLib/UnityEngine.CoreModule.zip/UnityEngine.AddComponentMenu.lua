---@class UnityEngine.AddComponentMenu : System.Attribute
---@field public componentMenu string
---@field public componentOrder number
local m = {}

UnityEngine.AddComponentMenu = m
return m
