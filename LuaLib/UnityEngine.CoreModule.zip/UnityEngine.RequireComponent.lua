---@class UnityEngine.RequireComponent : System.Attribute
---@field public m_Type0 System.Type
---@field public m_Type1 System.Type
---@field public m_Type2 System.Type
local m = {}

UnityEngine.RequireComponent = m
return m
