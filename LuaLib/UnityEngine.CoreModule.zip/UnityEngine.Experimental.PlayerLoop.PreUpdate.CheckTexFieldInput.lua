---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.CheckTexFieldInput : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.CheckTexFieldInput = m
return m
