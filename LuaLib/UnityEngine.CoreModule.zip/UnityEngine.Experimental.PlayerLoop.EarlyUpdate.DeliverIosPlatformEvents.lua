---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DeliverIosPlatformEvents : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DeliverIosPlatformEvents = m
return m
