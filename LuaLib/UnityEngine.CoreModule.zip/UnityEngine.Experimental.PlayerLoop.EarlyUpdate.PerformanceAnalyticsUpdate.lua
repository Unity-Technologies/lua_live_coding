---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PerformanceAnalyticsUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PerformanceAnalyticsUpdate = m
return m
