---@class UnityEngine.Experimental.Rendering.VertexAttribute : System.Enum
---@field public Position UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public Normal UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public Tangent UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public Color UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord0 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord1 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord2 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord3 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord4 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord5 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord6 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public TexCoord7 UnityEngine.Experimental.Rendering.VertexAttribute @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Rendering.VertexAttribute = m
return m
