---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateInputManager : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateInputManager = m
return m
