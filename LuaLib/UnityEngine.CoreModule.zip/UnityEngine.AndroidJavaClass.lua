---@class UnityEngine.AndroidJavaClass : UnityEngine.AndroidJavaObject
local m = {}

UnityEngine.AndroidJavaClass = m
return m
