---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DispatchEventQueueEvents : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.DispatchEventQueueEvents = m
return m
