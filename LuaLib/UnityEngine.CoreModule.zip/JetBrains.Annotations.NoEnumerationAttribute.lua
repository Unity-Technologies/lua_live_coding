---@class JetBrains.Annotations.NoEnumerationAttribute : System.Attribute
local m = {}

JetBrains.Annotations.NoEnumerationAttribute = m
return m
