---@class UnityEngine.Rendering.ShadowMapPass : System.Enum
---@field public PointlightPositiveX UnityEngine.Rendering.ShadowMapPass @static
---@field public PointlightNegativeX UnityEngine.Rendering.ShadowMapPass @static
---@field public PointlightPositiveY UnityEngine.Rendering.ShadowMapPass @static
---@field public PointlightNegativeY UnityEngine.Rendering.ShadowMapPass @static
---@field public PointlightPositiveZ UnityEngine.Rendering.ShadowMapPass @static
---@field public PointlightNegativeZ UnityEngine.Rendering.ShadowMapPass @static
---@field public DirectionalCascade0 UnityEngine.Rendering.ShadowMapPass @static
---@field public DirectionalCascade1 UnityEngine.Rendering.ShadowMapPass @static
---@field public DirectionalCascade2 UnityEngine.Rendering.ShadowMapPass @static
---@field public DirectionalCascade3 UnityEngine.Rendering.ShadowMapPass @static
---@field public Spotlight UnityEngine.Rendering.ShadowMapPass @static
---@field public Pointlight UnityEngine.Rendering.ShadowMapPass @static
---@field public Directional UnityEngine.Rendering.ShadowMapPass @static
---@field public All UnityEngine.Rendering.ShadowMapPass @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ShadowMapPass = m
return m
