---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ResetFrameStatsAfterPresent : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.ResetFrameStatsAfterPresent = m
return m
