---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCaptureScreenshot : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCaptureScreenshot = m
return m
