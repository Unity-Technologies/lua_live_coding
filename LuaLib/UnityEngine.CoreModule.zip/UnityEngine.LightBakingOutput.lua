---@class UnityEngine.LightBakingOutput : System.ValueType
---@field public probeOcclusionLightIndex number
---@field public occlusionMaskChannel number
---@field public lightmapBakeType UnityEngine.LightmapBakeType
---@field public mixedLightingMode UnityEngine.MixedLightingMode
---@field public isBaked boolean
local m = {}

UnityEngine.LightBakingOutput = m
return m
