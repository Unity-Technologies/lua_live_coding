---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UpdateNetworkManager : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.UpdateNetworkManager = m
return m
