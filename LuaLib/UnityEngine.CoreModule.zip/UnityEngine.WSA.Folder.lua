---@class UnityEngine.WSA.Folder : System.Enum
---@field public Installation UnityEngine.WSA.Folder @static
---@field public Temporary UnityEngine.WSA.Folder @static
---@field public Local UnityEngine.WSA.Folder @static
---@field public Roaming UnityEngine.WSA.Folder @static
---@field public CameraRoll UnityEngine.WSA.Folder @static
---@field public DocumentsLibrary UnityEngine.WSA.Folder @static
---@field public HomeGroup UnityEngine.WSA.Folder @static
---@field public MediaServerDevices UnityEngine.WSA.Folder @static
---@field public MusicLibrary UnityEngine.WSA.Folder @static
---@field public PicturesLibrary UnityEngine.WSA.Folder @static
---@field public Playlists UnityEngine.WSA.Folder @static
---@field public RemovableDevices UnityEngine.WSA.Folder @static
---@field public SavedPictures UnityEngine.WSA.Folder @static
---@field public VideosLibrary UnityEngine.WSA.Folder @static
---@field public value__ number
local m = {}

UnityEngine.WSA.Folder = m
return m
