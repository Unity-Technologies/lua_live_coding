---@class UnityEngine.ComputeBufferType : System.Enum
---@field public Default UnityEngine.ComputeBufferType @static
---@field public Raw UnityEngine.ComputeBufferType @static
---@field public Append UnityEngine.ComputeBufferType @static
---@field public Counter UnityEngine.ComputeBufferType @static
---@field public DrawIndirect UnityEngine.ComputeBufferType @static
---@field public IndirectArguments UnityEngine.ComputeBufferType @static
---@field public GPUMemory UnityEngine.ComputeBufferType @static
---@field public value__ number
local m = {}

UnityEngine.ComputeBufferType = m
return m
