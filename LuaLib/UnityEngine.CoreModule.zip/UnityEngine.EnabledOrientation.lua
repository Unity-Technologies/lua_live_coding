---@class UnityEngine.EnabledOrientation : System.Enum
---@field public kAutorotateToPortrait UnityEngine.EnabledOrientation @static
---@field public kAutorotateToPortraitUpsideDown UnityEngine.EnabledOrientation @static
---@field public kAutorotateToLandscapeLeft UnityEngine.EnabledOrientation @static
---@field public kAutorotateToLandscapeRight UnityEngine.EnabledOrientation @static
---@field public value__ number
local m = {}

UnityEngine.EnabledOrientation = m
return m
