---@class UnityEngine.Experimental.PlayerLoop.Initialization.SynchronizeState : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization.SynchronizeState = m
return m
