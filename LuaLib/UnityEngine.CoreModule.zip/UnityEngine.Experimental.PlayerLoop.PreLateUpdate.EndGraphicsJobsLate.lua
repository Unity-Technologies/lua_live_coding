---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.EndGraphicsJobsLate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.EndGraphicsJobsLate = m
return m
