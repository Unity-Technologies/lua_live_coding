---@class UnityEngine.WrapMode : System.Enum
---@field public Once UnityEngine.WrapMode @static
---@field public Loop UnityEngine.WrapMode @static
---@field public PingPong UnityEngine.WrapMode @static
---@field public Default UnityEngine.WrapMode @static
---@field public ClampForever UnityEngine.WrapMode @static
---@field public Clamp UnityEngine.WrapMode @static
---@field public value__ number
local m = {}

UnityEngine.WrapMode = m
return m
