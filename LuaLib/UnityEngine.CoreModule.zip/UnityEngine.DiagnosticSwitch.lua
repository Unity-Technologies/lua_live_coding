---@class UnityEngine.DiagnosticSwitch : System.ValueType
---@field public name string
---@field public description string
---@field public flags UnityEngine.DiagnosticSwitchFlags
---@field public value any
---@field public minValue any
---@field public maxValue any
---@field public persistentValue any
---@field public enumInfo UnityEngine.EnumInfo
local m = {}

UnityEngine.DiagnosticSwitch = m
return m
