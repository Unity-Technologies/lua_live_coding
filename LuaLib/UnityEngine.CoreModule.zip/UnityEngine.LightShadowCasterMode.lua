---@class UnityEngine.LightShadowCasterMode : System.Enum
---@field public Default UnityEngine.LightShadowCasterMode @static
---@field public NonLightmappedOnly UnityEngine.LightShadowCasterMode @static
---@field public Everything UnityEngine.LightShadowCasterMode @static
---@field public value__ number
local m = {}

UnityEngine.LightShadowCasterMode = m
return m
