---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PresentBeforeUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.PresentBeforeUpdate = m
return m
