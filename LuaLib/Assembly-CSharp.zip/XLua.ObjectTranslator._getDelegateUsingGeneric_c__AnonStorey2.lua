---@class XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey2 : System.Object
local m = {}

XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey2 = m
return m
