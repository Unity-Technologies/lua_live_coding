---@class XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey0 : System.Object
local m = {}

XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey0 = m
return m
