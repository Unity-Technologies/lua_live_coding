---@class UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar : UnityEngine.MonoBehaviour
---@field public axis string
local m = {}

---@param value number
function m:HandleInput(value) end

UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar = m
return m
