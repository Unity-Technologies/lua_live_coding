---@class XLua.Cast.Any_1_System_Char_ : System.Object
---@field public Target any
local m = {}

XLua.Cast.Any_1_System_Char_ = m
return m
