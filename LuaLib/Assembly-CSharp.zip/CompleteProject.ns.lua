---@class CompleteProject
CompleteProject = {}