---@class XLua.Cast.Byte : XLua.Cast.Any_1_System_Byte_
local m = {}

XLua.Cast.Byte = m
return m
