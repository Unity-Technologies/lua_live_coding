---@class G6HotFix.Scripts.Core
G6HotFix.Scripts.Core = {}