---@class CompleteProject.CameraFollow : UnityEngine.MonoBehaviour
---@field public target UnityEngine.Transform
---@field public smoothing number
local m = {}

CompleteProject.CameraFollow = m
return m
