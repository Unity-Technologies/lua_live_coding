---@class XLua.LuaIndexes : System.Object
---@field public LUA_REGISTRYINDEX number @static
local m = {}

XLua.LuaIndexes = m
return m
