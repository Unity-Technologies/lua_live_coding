---@class XLua.Utils._makeReflectionWrap_c__AnonStorey6 : System.Object
local m = {}

XLua.Utils._makeReflectionWrap_c__AnonStorey6 = m
return m
