---@class XLua.Cast
XLua.Cast = {}