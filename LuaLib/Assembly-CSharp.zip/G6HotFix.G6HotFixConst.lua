---@class G6HotFix.G6HotFixConst : System.Object
---@field public LUA_SOURCES_PATH string @static
local m = {}

G6HotFix.G6HotFixConst = m
return m
