---@class XLua.DoNotGenAttribute : System.Attribute
local m = {}

XLua.DoNotGenAttribute = m
return m
