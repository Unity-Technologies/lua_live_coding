---@class UnityStandardAssets.CrossPlatformInput.Inspector.TiltInputAxisStylePropertyDrawer : UnityEditor.PropertyDrawer
local m = {}

---@virtual
---@param position UnityEngine.Rect
---@param property UnityEditor.SerializedProperty
---@param label UnityEngine.GUIContent
function m:OnGUI(position, property, label) end

UnityStandardAssets.CrossPlatformInput.Inspector.TiltInputAxisStylePropertyDrawer = m
return m
