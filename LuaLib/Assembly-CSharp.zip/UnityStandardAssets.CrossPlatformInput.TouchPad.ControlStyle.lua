---@class UnityStandardAssets.CrossPlatformInput.TouchPad.ControlStyle : System.Enum
---@field public Absolute UnityStandardAssets.CrossPlatformInput.TouchPad.ControlStyle @static
---@field public Relative UnityStandardAssets.CrossPlatformInput.TouchPad.ControlStyle @static
---@field public Swipe UnityStandardAssets.CrossPlatformInput.TouchPad.ControlStyle @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.TouchPad.ControlStyle = m
return m
