---@class G6HotFix.Scripts.Core.Event : System.Object
local m = {}

G6HotFix.Scripts.Core.Event = m
return m
