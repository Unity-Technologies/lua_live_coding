---@class ____AnonType1_2__type___T__method___T_ : System.Object
---@field public type any
---@field public method any
local m = {}

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

____AnonType1_2__type___T__method___T_ = m
return m
