---@class UnityStandardAssets.CrossPlatformInput.ButtonHandler : UnityEngine.MonoBehaviour
---@field public Name string
local m = {}

function m:SetDownState() end

function m:SetUpState() end

function m:SetAxisPositiveState() end

function m:SetAxisNeutralState() end

function m:SetAxisNegativeState() end

function m:Update() end

UnityStandardAssets.CrossPlatformInput.ButtonHandler = m
return m
