---@class G6Demo.Core
G6Demo.Core = {}