---@class XLua.ObjectTranslator._RegisterPushAndGetAndUpdate_c__AnonStorey4_1_T_ : System.Object
local m = {}

XLua.ObjectTranslator._RegisterPushAndGetAndUpdate_c__AnonStorey4_1_T_ = m
return m
