---@class XLua.LuaTable._GetKeys_c__Iterator1_1_T_ : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

XLua.LuaTable._GetKeys_c__Iterator1_1_T_ = m
return m
