---@class XLua.Utils._genItemSetter_c__AnonStorey4 : System.Object
local m = {}

XLua.Utils._genItemSetter_c__AnonStorey4 = m
return m
