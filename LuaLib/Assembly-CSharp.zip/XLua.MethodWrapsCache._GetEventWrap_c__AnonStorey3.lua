---@class XLua.MethodWrapsCache._GetEventWrap_c__AnonStorey3 : System.Object
local m = {}

XLua.MethodWrapsCache._GetEventWrap_c__AnonStorey3 = m
return m
