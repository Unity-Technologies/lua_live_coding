---@class G6HotFix.LuaScripts.ILuaModelManager : table
local m = {}

---@abstract
function m:InitModels() end

G6HotFix.LuaScripts.ILuaModelManager = m
return m
