---@class GameObjectUtil._SetLayerRecur_c__AnonStorey0 : System.Object
local m = {}

GameObjectUtil._SetLayerRecur_c__AnonStorey0 = m
return m
