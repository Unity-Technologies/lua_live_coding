---@class UnityStandardAssets.CrossPlatformInput.Joystick.AxisOption : System.Enum
---@field public Both UnityStandardAssets.CrossPlatformInput.Joystick.AxisOption @static
---@field public OnlyHorizontal UnityStandardAssets.CrossPlatformInput.Joystick.AxisOption @static
---@field public OnlyVertical UnityStandardAssets.CrossPlatformInput.Joystick.AxisOption @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.Joystick.AxisOption = m
return m
