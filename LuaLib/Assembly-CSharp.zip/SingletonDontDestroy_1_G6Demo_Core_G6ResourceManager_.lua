---@class SingletonDontDestroy_1_G6Demo_Core_G6ResourceManager_ : UnityEngine.MonoBehaviour
---@field public Instance G6Demo.Core.G6ResourceManager @static
local m = {}

SingletonDontDestroy_1_G6Demo_Core_G6ResourceManager_ = m
return m
