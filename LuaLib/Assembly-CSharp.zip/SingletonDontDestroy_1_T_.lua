---@class SingletonDontDestroy_1_T_ : UnityEngine.MonoBehaviour
---@field public Instance UnityEngine.MonoBehaviour @static
local m = {}

SingletonDontDestroy_1_T_ = m
return m
