---@class XLua.ObjectCasters._genCaster_c__AnonStorey0 : System.Object
local m = {}

XLua.ObjectCasters._genCaster_c__AnonStorey0 = m
return m
