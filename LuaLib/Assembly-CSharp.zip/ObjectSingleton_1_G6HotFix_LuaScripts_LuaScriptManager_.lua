---@class ObjectSingleton_1_G6HotFix_LuaScripts_LuaScriptManager_ : System.Object
---@field public Instance G6HotFix.LuaScripts.LuaScriptManager @static
local m = {}

ObjectSingleton_1_G6HotFix_LuaScripts_LuaScriptManager_ = m
return m
