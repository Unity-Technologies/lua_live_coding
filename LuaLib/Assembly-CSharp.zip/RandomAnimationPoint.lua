---@class RandomAnimationPoint : UnityEngine.MonoBehaviour
---@field public randomize boolean
---@field public normalizedTime number
local m = {}

RandomAnimationPoint = m
return m
