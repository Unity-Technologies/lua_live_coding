---@class CompleteProject.EnemyMovement : UnityEngine.MonoBehaviour
local m = {}

CompleteProject.EnemyMovement = m
return m
