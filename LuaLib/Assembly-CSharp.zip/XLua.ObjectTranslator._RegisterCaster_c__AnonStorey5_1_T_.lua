---@class XLua.ObjectTranslator._RegisterCaster_c__AnonStorey5_1_T_ : System.Object
local m = {}

XLua.ObjectTranslator._RegisterCaster_c__AnonStorey5_1_T_ = m
return m
