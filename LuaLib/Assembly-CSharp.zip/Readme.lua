---@class Readme : UnityEngine.ScriptableObject
---@field public icon UnityEngine.Texture2D
---@field public title string
---@field public sections Readme.Section[]
---@field public loadedLayout boolean
local m = {}

Readme = m
return m
