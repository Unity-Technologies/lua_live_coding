---@class XLua.Utils._ReflectionWrap_c__AnonStorey8 : System.Object
local m = {}

XLua.Utils._ReflectionWrap_c__AnonStorey8 = m
return m
