---@class G6HotFix
G6HotFix = {}