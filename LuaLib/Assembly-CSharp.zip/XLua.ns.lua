---@class XLua
XLua = {}