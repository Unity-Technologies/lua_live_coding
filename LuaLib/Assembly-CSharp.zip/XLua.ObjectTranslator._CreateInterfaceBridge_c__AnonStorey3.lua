---@class XLua.ObjectTranslator._CreateInterfaceBridge_c__AnonStorey3 : System.Object
local m = {}

XLua.ObjectTranslator._CreateInterfaceBridge_c__AnonStorey3 = m
return m
