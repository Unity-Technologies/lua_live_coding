---@class XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey1 : System.Object
local m = {}

XLua.ObjectTranslator._getDelegateUsingGeneric_c__AnonStorey1 = m
return m
