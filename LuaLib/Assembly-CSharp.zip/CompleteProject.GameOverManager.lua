---@class CompleteProject.GameOverManager : UnityEngine.MonoBehaviour
local m = {}

CompleteProject.GameOverManager = m
return m
