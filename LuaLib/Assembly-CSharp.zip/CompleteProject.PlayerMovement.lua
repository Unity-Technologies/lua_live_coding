---@class CompleteProject.PlayerMovement : UnityEngine.MonoBehaviour
---@field public speed number
local m = {}

CompleteProject.PlayerMovement = m
return m
