---@class XLua.LuaDLL
XLua.LuaDLL = {}