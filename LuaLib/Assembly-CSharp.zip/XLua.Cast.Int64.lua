---@class XLua.Cast.Int64 : XLua.Cast.Any_1_System_Int64_
local m = {}

XLua.Cast.Int64 = m
return m
