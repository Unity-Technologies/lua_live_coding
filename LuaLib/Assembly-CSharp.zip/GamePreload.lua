---@class GamePreload : UnityEngine.MonoBehaviour
local m = {}

GamePreload = m
return m
