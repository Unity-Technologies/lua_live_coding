---@class XLua.Utils._genFieldSetter_c__AnonStorey2 : System.Object
local m = {}

XLua.Utils._genFieldSetter_c__AnonStorey2 = m
return m
