---@class UnityStandardAssets.CrossPlatformInput.PlatformSpecific
UnityStandardAssets.CrossPlatformInput.PlatformSpecific = {}