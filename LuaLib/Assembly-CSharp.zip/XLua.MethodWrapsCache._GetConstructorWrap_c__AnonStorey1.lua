---@class XLua.MethodWrapsCache._GetConstructorWrap_c__AnonStorey1 : System.Object
local m = {}

XLua.MethodWrapsCache._GetConstructorWrap_c__AnonStorey1 = m
return m
