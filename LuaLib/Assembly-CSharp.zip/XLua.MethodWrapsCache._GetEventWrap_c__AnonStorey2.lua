---@class XLua.MethodWrapsCache._GetEventWrap_c__AnonStorey2 : System.Object
local m = {}

XLua.MethodWrapsCache._GetEventWrap_c__AnonStorey2 = m
return m
