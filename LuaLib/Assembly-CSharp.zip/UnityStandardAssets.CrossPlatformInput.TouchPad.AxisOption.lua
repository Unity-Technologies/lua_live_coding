---@class UnityStandardAssets.CrossPlatformInput.TouchPad.AxisOption : System.Enum
---@field public Both UnityStandardAssets.CrossPlatformInput.TouchPad.AxisOption @static
---@field public OnlyHorizontal UnityStandardAssets.CrossPlatformInput.TouchPad.AxisOption @static
---@field public OnlyVertical UnityStandardAssets.CrossPlatformInput.TouchPad.AxisOption @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.TouchPad.AxisOption = m
return m
