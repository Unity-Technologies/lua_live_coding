---@class UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.ActiveInputMethod : System.Enum
---@field public Hardware UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.ActiveInputMethod @static
---@field public Touch UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.ActiveInputMethod @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.ActiveInputMethod = m
return m
