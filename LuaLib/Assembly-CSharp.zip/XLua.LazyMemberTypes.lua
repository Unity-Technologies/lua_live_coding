---@class XLua.LazyMemberTypes : System.Enum
---@field public Method XLua.LazyMemberTypes @static
---@field public FieldGet XLua.LazyMemberTypes @static
---@field public FieldSet XLua.LazyMemberTypes @static
---@field public PropertyGet XLua.LazyMemberTypes @static
---@field public PropertySet XLua.LazyMemberTypes @static
---@field public Event XLua.LazyMemberTypes @static
---@field public value__ number
local m = {}

XLua.LazyMemberTypes = m
return m
