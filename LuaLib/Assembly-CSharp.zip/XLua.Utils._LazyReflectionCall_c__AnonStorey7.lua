---@class XLua.Utils._LazyReflectionCall_c__AnonStorey7 : System.Object
local m = {}

XLua.Utils._LazyReflectionCall_c__AnonStorey7 = m
return m
