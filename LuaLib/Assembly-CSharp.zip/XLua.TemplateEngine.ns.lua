---@class XLua.TemplateEngine
XLua.TemplateEngine = {}