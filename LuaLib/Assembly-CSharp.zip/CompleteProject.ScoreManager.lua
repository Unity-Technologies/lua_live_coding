---@class CompleteProject.ScoreManager : UnityEngine.MonoBehaviour
---@field public score number @static
local m = {}

CompleteProject.ScoreManager = m
return m
