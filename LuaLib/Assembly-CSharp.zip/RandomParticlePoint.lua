---@class RandomParticlePoint : UnityEngine.MonoBehaviour
---@field public normalizedTime number
local m = {}

RandomParticlePoint = m
return m
