---@class XLua.Utils._genEnumCastFrom_c__AnonStorey5 : System.Object
local m = {}

XLua.Utils._genEnumCastFrom_c__AnonStorey5 = m
return m
