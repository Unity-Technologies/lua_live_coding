---@class XLua.MethodWrapsCache._GetConstructorWrap_c__AnonStorey0 : System.Object
local m = {}

XLua.MethodWrapsCache._GetConstructorWrap_c__AnonStorey0 = m
return m
