---@class XLua.Utils._genItemGetter_c__AnonStorey3 : System.Object
local m = {}

XLua.Utils._genItemGetter_c__AnonStorey3 = m
return m
