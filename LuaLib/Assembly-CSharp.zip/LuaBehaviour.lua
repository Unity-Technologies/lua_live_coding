---@class LuaBehaviour : UnityEngine.MonoBehaviour
---@field public luaScript UnityEngine.TextAsset
---@field public injections Injection[]
local m = {}

LuaBehaviour = m
return m
