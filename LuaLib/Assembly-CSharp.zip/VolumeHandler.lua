---@class VolumeHandler : UnityEngine.MonoBehaviour
local m = {}

VolumeHandler = m
return m
