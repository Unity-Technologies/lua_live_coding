---@class XLua.ObjectCasters._genNullableCaster_c__AnonStorey3 : System.Object
local m = {}

XLua.ObjectCasters._genNullableCaster_c__AnonStorey3 = m
return m
