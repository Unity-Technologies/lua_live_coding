---@class UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType : System.Enum
---@field public NamedAxis UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType @static
---@field public MousePositionX UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType @static
---@field public MousePositionY UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType @static
---@field public MousePositionZ UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType = m
return m
