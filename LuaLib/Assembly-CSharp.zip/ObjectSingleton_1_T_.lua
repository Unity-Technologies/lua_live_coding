---@class ObjectSingleton_1_T_ : System.Object
---@field public Instance any @static
local m = {}

ObjectSingleton_1_T_ = m
return m
