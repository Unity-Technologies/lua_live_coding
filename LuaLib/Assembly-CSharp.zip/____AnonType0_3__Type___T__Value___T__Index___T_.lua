---@class ____AnonType0_3__Type___T__Value___T__Index___T_ : System.Object
---@field public Type any
---@field public Value any
---@field public Index any
local m = {}

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

____AnonType0_3__Type___T__Value___T__Index___T_ = m
return m
