---@class SingletonDontDestroy_1_LuaBehaviourManager_ : UnityEngine.MonoBehaviour
---@field public Instance LuaBehaviourManager @static
local m = {}

SingletonDontDestroy_1_LuaBehaviourManager_ = m
return m
