---@class XLua.HotfixDelegateAttribute : System.Attribute
local m = {}

XLua.HotfixDelegateAttribute = m
return m
