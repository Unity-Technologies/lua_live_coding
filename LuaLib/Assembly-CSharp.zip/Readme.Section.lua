---@class Readme.Section : System.Object
---@field public heading string
---@field public text string
---@field public linkText string
---@field public url string
local m = {}

Readme.Section = m
return m
