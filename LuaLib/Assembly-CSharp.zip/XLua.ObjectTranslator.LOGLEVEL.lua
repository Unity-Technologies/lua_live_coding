---@class XLua.ObjectTranslator.LOGLEVEL : System.Enum
---@field public NO XLua.ObjectTranslator.LOGLEVEL @static
---@field public INFO XLua.ObjectTranslator.LOGLEVEL @static
---@field public WARN XLua.ObjectTranslator.LOGLEVEL @static
---@field public ERROR XLua.ObjectTranslator.LOGLEVEL @static
---@field public value__ number
local m = {}

XLua.ObjectTranslator.LOGLEVEL = m
return m
