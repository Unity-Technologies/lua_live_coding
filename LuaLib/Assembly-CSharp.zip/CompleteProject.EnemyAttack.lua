---@class CompleteProject.EnemyAttack : UnityEngine.MonoBehaviour
---@field public timeBetweenAttacks number
---@field public attackDamage number
local m = {}

CompleteProject.EnemyAttack = m
return m
