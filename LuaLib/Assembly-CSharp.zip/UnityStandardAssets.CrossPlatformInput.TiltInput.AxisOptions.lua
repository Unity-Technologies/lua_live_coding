---@class UnityStandardAssets.CrossPlatformInput.TiltInput.AxisOptions : System.Enum
---@field public ForwardAxis UnityStandardAssets.CrossPlatformInput.TiltInput.AxisOptions @static
---@field public SidewaysAxis UnityStandardAssets.CrossPlatformInput.TiltInput.AxisOptions @static
---@field public value__ number
local m = {}

UnityStandardAssets.CrossPlatformInput.TiltInput.AxisOptions = m
return m
