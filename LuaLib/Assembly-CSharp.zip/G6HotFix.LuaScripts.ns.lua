---@class G6HotFix.LuaScripts
G6HotFix.LuaScripts = {}