---@class XLuaBehaviour : UnityEngine.MonoBehaviour
---@field public injections Injection[]
local m = {}

XLuaBehaviour = m
return m
