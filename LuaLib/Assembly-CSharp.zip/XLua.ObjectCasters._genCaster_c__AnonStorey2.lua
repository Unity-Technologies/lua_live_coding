---@class XLua.ObjectCasters._genCaster_c__AnonStorey2 : System.Object
local m = {}

XLua.ObjectCasters._genCaster_c__AnonStorey2 = m
return m
