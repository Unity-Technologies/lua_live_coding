---@class UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping : System.Object
---@field public type UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping.MappingType
---@field public axisName string
local m = {}

UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping = m
return m
