---@class UnityStandardAssets.CrossPlatformInput
UnityStandardAssets.CrossPlatformInput = {}