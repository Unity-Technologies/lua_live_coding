---@class XLua.Utils._genFieldGetter_c__AnonStorey1 : System.Object
local m = {}

XLua.Utils._genFieldGetter_c__AnonStorey1 = m
return m
