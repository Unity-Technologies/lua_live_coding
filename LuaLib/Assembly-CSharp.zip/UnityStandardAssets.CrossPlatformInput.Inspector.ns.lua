---@class UnityStandardAssets.CrossPlatformInput.Inspector
UnityStandardAssets.CrossPlatformInput.Inspector = {}